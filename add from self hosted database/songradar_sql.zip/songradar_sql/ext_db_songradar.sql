-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2023 at 05:57 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ext_db_songradar`
--

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `performers` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`id`, `title`, `performers`, `year`, `genre`) VALUES
(7, 'ext_3', 'artist_la', 1000, 'la'),
(8, 'ext_4', 'vredgtegv', 555, 'very er'),
(9, 'ext_5', 'y', 2000, 'y'),
(10, 'ext_6', 'singer', 3000, 'pop'),
(11, 'ext_1', 'artist2', 2010, 'Pop'),
(12, 'ext_2', 'artist2', 2001, 'Metal');

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `performers` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `album_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`id`, `title`, `performers`, `year`, `genre`, `album_id`) VALUES
(2, 'TEST SONG', 'Harry', 0, 'POP', NULL),
(5, 'song2', 'artist2', 2010, 'Pop', NULL),
(6, 'song3', 'artist2', 2001, 'Metal', NULL),
(10, 'lalala', 'artist2', 1000, 'la', NULL),
(11, 'song_of_artist_2', 'artist2', 2001, 'Metal', 14),
(12, 'artist2\'song', 'artist2', 2001, 'Metal', 14),
(17, 'some_song', '3fere', 3333, 'pop', NULL),
(19, 'song_of-artist_2', 'artist2', 2010, 'Pop', 13);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `hashed_password`) VALUES
(1, 'rezzan', 'rezzan@gmail.com', '$2b$12$oIr8.gwP0C.UsrY2LCoAH.GJIZah4hyd/.qPhbZK8/1Ow/FNF8Isy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_albums_year` (`year`),
  ADD KEY `ix_albums_title` (`title`),
  ADD KEY `ix_albums_id` (`id`),
  ADD KEY `ix_albums_genre` (`genre`),
  ADD KEY `ix_albums_performers` (`performers`);

--
-- Indexes for table `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_songs_performers` (`performers`),
  ADD KEY `ix_songs_year` (`year`),
  ADD KEY `ix_songs_id` (`id`),
  ADD KEY `ix_songs_genre` (`genre`),
  ADD KEY `ix_songs_title` (`title`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ix_users_email` (`email`),
  ADD UNIQUE KEY `ix_users_username` (`username`),
  ADD KEY `ix_users_id` (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `songs`
--
ALTER TABLE `songs`
  ADD CONSTRAINT `songs_ibfk_1` FOREIGN KEY (`album_id`) REFERENCES `albums` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
