<?php

global $db;

$db = new mysqli('localhost','root','','ext_db_songradar');



if ($db->connect_error) {
    die(json_encode(['error' => "Connection failed: " . $db->connect_error]));
}

$stmt = $db->prepare("SELECT * FROM albums ");

if ($stmt->execute()) {
    $result = $stmt->get_result();

    $res = array();
    while ($row = $result->fetch_assoc()) {
        $res[] = $row;
    }

    if (empty($res)) {
        echo json_encode(['message' => 'No albums found']);
    } else {
        echo json_encode($res);
    }

} else {
    echo json_encode(['error' => "Error executing query: " . $stmt->error]);
}

?>